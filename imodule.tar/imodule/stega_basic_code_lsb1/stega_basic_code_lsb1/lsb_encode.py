import wave

def text_to_binary(message):
    """Chuyen doi tin nhan thanh chuoi nhi phan."""
    return ''.join(format(ord(char), '08b') for char in message)

def lsb_encode(binary_file, message, output_wav):
    """Giau tin nhan vao file WAV su dung LSB."""
    try:
        # Doc du lieu nhi phan tu file output_binary.txt
        with open(binary_file, "r") as file:
            binary_data = file.read()
        
        # Chuyen tin nhan thanh bit nhi phan
        message_bits = text_to_binary(message) + '00000000'  # Dau ket thuc tin nhan
        
        if len(message_bits) > len(binary_data):
            print("File khong du dung luong de giau tin!")
            return
        
        # Giau tin vao LSB
        modified_data = list(binary_data)
        for i in range(len(message_bits)):
            modified_data[i] = modified_data[i][:-1] + message_bits[i]
        
        # Chia lai thanh cac byte dung
        modified_bytes = bytearray()
        for i in range(0, len(modified_data), 8):
            byte_str = ''.join(modified_data[i:i+8])
            if len(byte_str) == 8:
                modified_bytes.append(int(byte_str, 2))
        
        # Luu vao file WAV moi
        with wave.open(output_wav, 'wb') as wav_out:
            with wave.open("input.wav", 'rb') as wav_in:
                wav_out.setparams(wav_in.getparams())
                wav_out.writeframes(modified_bytes)
        
        print("Giau tin thanh cong!\n")
        print("File moi: " + output_wav) 
    except Exception as e:
        print(f"Loi khi giau tin: {e}")

if __name__ == "__main__":
    binary_file = "output_binary.txt"
    output_wav = "output.wav"
    message = input("Nhap tin nhan can giau: ")
    lsb_encode(binary_file, message, output_wav)

