def check_wav_capacity(binary_file, message):
    """Kiem tra xem file nhi phan co du dung luong de giau tin khong"""
    try:
        with open(binary_file, "r") as file:
            binary_data = file.read()
        
        available_bits = len(binary_data)
        required_bits = len(message) * 8
        
        print(f"Dung luong file nhi phan: {available_bits} bit")
        print(f"Dung luong tin can giau: {required_bits} bit")
        
        if available_bits >= required_bits:
            print("File du dung luong de giau tin")
            return True
        else:
            print("File khong du dung luong de giau tin")
            return False
    except Exception as e:
        print(f"Loi khi kiem tra file nhi phan: {e}")
        return False

if __name__ == "__main__":
    # Nhap tin nhan tu nguoi dung
    message = input("Nhap tin nhan can giau: ")
        
    # Kiem tra dung luong file va tin nhan
    binary_file = "output_binary.txt"  # Dau ra tu file chuyen doi WAV
    check_wav_capacity(binary_file, message)

