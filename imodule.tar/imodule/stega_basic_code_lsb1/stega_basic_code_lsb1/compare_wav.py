import numpy as np
import wave
import sys


# Hàm đọc dữ liệu âm thanh từ file .wav
def read_wav(filename):
    with wave.open(filename, 'r') as wav_file:
        frames = wav_file.readframes(-1)
        signal = np.frombuffer(frames, dtype=np.int16)
        return signal

# Đọc file âm thanh trước và sau khi giấu tin
original_signal = read_wav("input.wav")
stego_signal = read_wav("output.wav")

# Tính phần trăm sai khác
diff_percentage = np.sum(np.abs(original_signal - stego_signal)) / np.sum(np.abs(original_signal)) * 100
print(f"Muc do khac biet: {diff_percentage:.6f}%\n")
