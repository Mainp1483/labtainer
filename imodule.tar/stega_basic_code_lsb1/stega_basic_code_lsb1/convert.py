import wave

def read_wav_as_binary(file_path="input.wav"):
    """Chuyen doi file am thanh qua nhi phan."""
    try:
        with wave.open(file_path, 'rb') as wav_file:
            frames = wav_file.readframes(wav_file.getnframes())
            binary_data = ''.join(format(byte, '08b') for byte in frames)
            return binary_data
    except Exception as e:
        print(f"Loi khi doc file WAV: {e}")
        return None

if __name__ == "__main__":
    binary_output = read_wav_as_binary()
    if binary_output:
        with open("output_binary.txt", "w") as output_file:
            output_file.write(binary_output)
        print("Chuyen doi thanh cong, ket qua luu vao file output_binary.txt")

